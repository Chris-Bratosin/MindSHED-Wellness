import 'package:hive/hive.dart';
import 'package:intl/intl.dart';
import 'package:mindshed_app/wellness_predictor.dart';

enum Grade { red, amber, green }
enum DateRange { daily, weekly, monthly }

class InsightsEngine {
  final Box _metricsBox;
  WellnessPredictor? _predictor;

  InsightsEngine(this._metricsBox);

  Future<void> _ensurePredictor() async {
    if (_predictor == null) {
      _predictor = WellnessPredictor();
      await _predictor!.loadModel();
    }
  }

  Future<void> initPredictor() async => _ensurePredictor();
  void dispose() => _predictor?.close();

  Map<String, dynamic> _maskMealsByClock(Map<String, dynamic> f) {
    final mins = DateTime.now().hour * 60 + DateTime.now().minute;
    const bfEnd    = 10 * 60 + 30;
    const lunchEnd = 15 * 60;
    const dinEnd   = 21 * 60;
    const neutral  = '00:00';
    if (mins < bfEnd    && f['breakfast_time'] == null) f['breakfast_time'] = neutral;
    if (mins < lunchEnd && f['lunch_time']     == null) f['lunch_time']     = neutral;
    if (mins < dinEnd   && f['dinner_time']    == null) f['dinner_time']    = neutral;
    return f;
  }

  Map<String, dynamic> _pluckFeatures(Map<String, dynamic> raw) => {
        'sleep_bucket'      : raw['sleep_bucket']      as String? ?? raw['sleep_quality'] as String? ?? '',
        'exercise_bucket'   : raw['exercise_bucket']   as String? ?? raw['exercise']      as String? ?? '',
        'hydration_bucket'  : raw['hydration_bucket']  as String? ?? raw['hydration']     as String? ?? '',
        'mindset'           : raw['mindset']           as String? ?? '',
        'mindfulness_count' : (raw['mindfulness_activities'] as List?)?.length ?? 0,
        'breakfast_time'    : raw['breakfast_time']    as String? ?? '',
        'lunch_time'        : raw['lunch_time']        as String? ?? '',
        'dinner_time'       : raw['dinner_time']       as String? ?? '',
      };

  Future<int> getPredictedScore(String userId, DateRange range) async {
    await _ensurePredictor();
    final dates = _getDatesForRange(range);
    double total = 0;
    int    count = 0;

    for (final d in dates) {
      final raw = _metricsBox.get('${userId}_$d');
      if (raw is Map) {
        final feats = _pluckFeatures(_maskMealsByClock(Map.from(raw)));
        total += _predictor!.score(feats);
        count++;
      }
    }
    if (count == 0) return 0;
    return (total / count).round();
  }

  Future<Map<String, Grade>> getCategoryGrades(String userId, DateRange range) async {
    final dates     = _getDatesForRange(range);
    final catScores = <String, List<int>>{};

    for (final d in dates) {
      final data = _metricsBox.get('${userId}_$d');
      if (data is! Map) continue;
      final map       = Map<String, dynamic>.from(data);
      final dietTimes = <String>[];

      map.forEach((k, raw) {

        if (raw is Iterable && raw.isEmpty) return;
        if (k.endsWith('_val') || k == 'mindset') return;


        if (k == 'breakfast_time' || k == 'lunch_time' || k == 'dinner_time') {
          if ((raw as String).isNotEmpty) dietTimes.add(k);
          return;
        }

        if (k == 'hydration_bucket' || k == 'hydration') {
          final score = _gradeHydration(
            raw.toString(),
            map['exercise_bucket'] as String? ?? map['exercise'] as String? ?? '',
          );
          catScores.putIfAbsent('hydration', () => []).add(score);
          return;
        }

        final vals  = raw is Iterable ? List<String>.from(raw) : [raw.toString()];
        final score = _gradeCategory(k.toLowerCase(), vals);
        catScores.putIfAbsent(k, () => []).add(score);
      });

      if (dietTimes.isNotEmpty) {
        final dscore = _gradeCategory('diet', dietTimes);
        catScores.putIfAbsent('diet', () => []).add(dscore);
      }
    }

    return catScores.map((cat, list) {
      final avg = list.reduce((a, b) => a + b) / list.length;
      return MapEntry(cat.toLowerCase(), _scoreToGrade(avg));
    });
  }

  List<String> _getDatesForRange(DateRange r) {
    final now = DateTime.now(), fmt = DateFormat('yyyy-MM-dd');
    final len = r == DateRange.daily
        ? 1
        : r == DateRange.weekly
            ? 7
            : 30;
    return List.generate(len, (i) => fmt.format(now.subtract(Duration(days: i))));
  }

  int _gradeCategory(String key, List<String> vals) {
    switch (key) {
      case 'sleep_bucket':
      case 'sleep_quality':

        if (vals.contains('7-9 hours'))                      return 3;
        if (vals.contains('4-6 hours') || vals.contains('10+ hours')) return 2;
        return 1;

      case 'exercise_bucket':
      case 'exercise':

        if (vals.contains('30-60 minutes') || vals.contains('60+ minutes')) return 3;
        if (vals.contains('10-30 minutes'))                                     return 2;
        return 1;

      case 'mindfulness_activities':
        final n = vals.length;
        if (n >= 2) return 3;
        if (n == 1) return 2;
        return 1;

      case 'diet':
        final n    = vals.length;
        final mins = DateTime.now().hour * 60 + DateTime.now().minute;
        const bfEnd    = 10 * 60 + 30,
              lunchEnd = 15 * 60,
              dinEnd   = 21 * 60;
        final expected = mins < bfEnd ? 1 : mins < lunchEnd ? 2 : 3;
        if (n >= expected)     return 3;
        if (expected - n == 1) return 2;
        return 1;

      default:
        return 2;
    }
  }

  int _gradeHydration(String bucket, String exBucket) {

    final match = RegExp(r'(\d+(\.\d+)?)').firstMatch(bucket);
    final rawValue = match?.group(0) ?? '0';
    final drank = double.tryParse(rawValue) ?? 0.0;

    final drankRounded = double.parse(drank.toStringAsFixed(1));

    if (drankRounded < 2.0) {
      return 1; 
    }
    if (drankRounded <= 2.5) {
      return 3; 
    }
    return 2; 
  }

  Grade _scoreToGrade(double s) =>
      s >= 2.5 ? Grade.green : s >= 1.5 ? Grade.amber : Grade.red;
}