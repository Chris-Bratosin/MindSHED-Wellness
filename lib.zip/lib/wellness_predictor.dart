import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:tflite_flutter/tflite_flutter.dart';

class WellnessPredictor {
  late final Interpreter _interpreter;
  late final Map<String, dynamic> _meta;
  late final List<String> _featureOrder;

  Future<void> loadModel() async {
    _interpreter = await Interpreter.fromAsset('assets/wellness_grader.tflite');
    final metaStr = await rootBundle.loadString('assets/wellness_meta.json');
    _meta = jsonDecode(metaStr) as Map<String, dynamic>;
    _featureOrder = List<String>.from(_meta['feature_order'] as List);
  }

  double score(Map<String, dynamic> inputs) {

    final vector = Float32List(_featureOrder.length);
    for (var i = 0; i < _featureOrder.length; i++) {
      vector[i] = _encode(_featureOrder[i], inputs[_featureOrder[i]]);
    }

    final inputBatch = [vector];

    final outputBatch = List.generate(1, (_) => List<double>.filled(1, 0.0));

    _interpreter.run(inputBatch, outputBatch);

    final raw = outputBatch[0][0];        
    return (raw * 100).clamp(0, 100);     
  }

  double _encode(String key, dynamic v) {
    if (v == null) return -1;

    if (v is Iterable) return v.length.toDouble();
    if (v is num) return v.toDouble();

    if (v is String) {

      final catMap = (_meta['categorical_mapping'] as Map<String, dynamic>)[key];
      if (catMap != null) {
        final map = Map<String, int>.from(catMap as Map);
        return (map[v] ?? -1).toDouble();
      }

      final timeCols = List<String>.from(_meta['time_columns_normalized'] as List);
      if (timeCols.contains(key)) {
        final parts = v.split(':');
        if (parts.length == 2) {
          final mins = int.parse(parts[0]) * 60 + int.parse(parts[1]);
          return mins / 1440.0;
        }
      }
    }

    return -1;
  }

  void close() => _interpreter.close();
}